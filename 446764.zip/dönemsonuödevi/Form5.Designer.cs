﻿namespace dönemsonuödevi
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.denekDataSet = new dönemsonuödevi.DenekDataSet();
            this.denekDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aaaaaa = new System.Windows.Forms.Label();
            this.kırmızıadasdadasdsa = new System.Windows.Forms.Label();
            this.oyuncubilTableAdapter1 = new dönemsonuödevi.DenekDataSetTableAdapters.oyuncubilTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.maviadsadsa = new System.Windows.Forms.Label();
            this.dene = new System.Windows.Forms.Button();
            this.yesil = new System.Windows.Forms.Label();
            this.mavi = new System.Windows.Forms.Label();
            this.kırmızı = new System.Windows.Forms.Label();
            this.hak = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Sil = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // denekDataSet
            // 
            this.denekDataSet.DataSetName = "DenekDataSet";
            this.denekDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // denekDataSetBindingSource
            // 
            this.denekDataSetBindingSource.DataSource = this.denekDataSet;
            this.denekDataSetBindingSource.Position = 0;
            // 
            // aaaaaa
            // 
            this.aaaaaa.AutoSize = true;
            this.aaaaaa.ForeColor = System.Drawing.Color.LawnGreen;
            this.aaaaaa.Location = new System.Drawing.Point(268, 218);
            this.aaaaaa.Name = "aaaaaa";
            this.aaaaaa.Size = new System.Drawing.Size(27, 13);
            this.aaaaaa.TabIndex = 0;
            this.aaaaaa.Text = "yeşil";
            // 
            // kırmızıadasdadasdsa
            // 
            this.kırmızıadasdadasdsa.AutoSize = true;
            this.kırmızıadasdadasdsa.ForeColor = System.Drawing.Color.Crimson;
            this.kırmızıadasdadasdsa.Location = new System.Drawing.Point(513, 218);
            this.kırmızıadasdadasdsa.Name = "kırmızıadasdadasdsa";
            this.kırmızıadasdadasdsa.Size = new System.Drawing.Size(35, 13);
            this.kırmızıadasdadasdsa.TabIndex = 2;
            this.kırmızıadasdadasdsa.Text = "kırmızı";
            // 
            // oyuncubilTableAdapter1
            // 
            this.oyuncubilTableAdapter1.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Symbol", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(204, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(361, 30);
            this.label4.TabIndex = 4;
            this.label4.Text = "3 BASAMAKLI SAYI BILME OYUNU";
            this.label4.DoubleClick += new System.EventHandler(this.label4_DoubleClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(633, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 38);
            this.button1.TabIndex = 5;
            this.button1.Text = "Yeni oyun / yeniden başla";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // maviadsadsa
            // 
            this.maviadsadsa.AutoSize = true;
            this.maviadsadsa.ForeColor = System.Drawing.Color.MidnightBlue;
            this.maviadsadsa.Location = new System.Drawing.Point(382, 218);
            this.maviadsadsa.Name = "maviadsadsa";
            this.maviadsadsa.Size = new System.Drawing.Size(29, 13);
            this.maviadsadsa.TabIndex = 6;
            this.maviadsadsa.Text = "mavi";
            // 
            // dene
            // 
            this.dene.Location = new System.Drawing.Point(633, 175);
            this.dene.Name = "dene";
            this.dene.Size = new System.Drawing.Size(84, 38);
            this.dene.TabIndex = 7;
            this.dene.Text = "Dene!";
            this.dene.UseVisualStyleBackColor = true;
            this.dene.Click += new System.EventHandler(this.dene_Click);
            // 
            // yesil
            // 
            this.yesil.AutoSize = true;
            this.yesil.ForeColor = System.Drawing.Color.Lime;
            this.yesil.Location = new System.Drawing.Point(249, 218);
            this.yesil.Name = "yesil";
            this.yesil.Size = new System.Drawing.Size(13, 13);
            this.yesil.TabIndex = 8;
            this.yesil.Text = "0";
            this.yesil.Click += new System.EventHandler(this.label1_Click);
            // 
            // mavi
            // 
            this.mavi.AutoSize = true;
            this.mavi.ForeColor = System.Drawing.Color.Navy;
            this.mavi.Location = new System.Drawing.Point(363, 218);
            this.mavi.Name = "mavi";
            this.mavi.Size = new System.Drawing.Size(13, 13);
            this.mavi.TabIndex = 9;
            this.mavi.Text = "0";
            // 
            // kırmızı
            // 
            this.kırmızı.AutoSize = true;
            this.kırmızı.ForeColor = System.Drawing.Color.Crimson;
            this.kırmızı.Location = new System.Drawing.Point(494, 218);
            this.kırmızı.Name = "kırmızı";
            this.kırmızı.Size = new System.Drawing.Size(13, 13);
            this.kırmızı.TabIndex = 10;
            this.kırmızı.Text = "0";
            // 
            // hak
            // 
            this.hak.AutoSize = true;
            this.hak.Font = new System.Drawing.Font("Palatino Linotype", 16.30189F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.hak.ForeColor = System.Drawing.Color.Navy;
            this.hak.Location = new System.Drawing.Point(201, 158);
            this.hak.Name = "hak";
            this.hak.Size = new System.Drawing.Size(41, 34);
            this.hak.TabIndex = 11;
            this.hak.Text = "10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(3, 163);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "Kalan hak sayınız:";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Impact", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox1.ForeColor = System.Drawing.Color.Red;
            this.richTextBox1.Location = new System.Drawing.Point(248, 163);
            this.richTextBox1.MaxLength = 3;
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(311, 29);
            this.richTextBox1.TabIndex = 13;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Sil
            // 
            this.Sil.Location = new System.Drawing.Point(129, 344);
            this.Sil.Name = "Sil";
            this.Sil.Size = new System.Drawing.Size(35, 36);
            this.Sil.TabIndex = 49;
            this.Sil.Text = "Sil";
            this.Sil.UseVisualStyleBackColor = true;
            this.Sil.Click += new System.EventHandler(this.Sil_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(88, 344);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(35, 36);
            this.button10.TabIndex = 48;
            this.button10.Text = "0";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(129, 302);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 36);
            this.button9.TabIndex = 47;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(88, 302);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(35, 36);
            this.button8.TabIndex = 46;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(47, 302);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 36);
            this.button7.TabIndex = 45;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(129, 260);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 36);
            this.button6.TabIndex = 44;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(88, 260);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 36);
            this.button5.TabIndex = 43;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(47, 260);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 36);
            this.button4.TabIndex = 42;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(129, 218);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 36);
            this.button3.TabIndex = 41;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(88, 218);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(35, 36);
            this.button11.TabIndex = 40;
            this.button11.Text = "2";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(47, 218);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(35, 36);
            this.button12.TabIndex = 39;
            this.button12.Text = "1";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 16.30189F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(452, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 33);
            this.label2.TabIndex = 65;
            this.label2.Text = "Skor Tablosu";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(281, 274);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 45;
            this.dataGridView1.Size = new System.Drawing.Size(464, 115);
            this.dataGridView1.TabIndex = 64;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(825, 439);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Sil);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hak);
            this.Controls.Add(this.kırmızı);
            this.Controls.Add(this.mavi);
            this.Controls.Add(this.yesil);
            this.Controls.Add(this.dene);
            this.Controls.Add(this.maviadsadsa);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.kırmızıadasdadasdsa);
            this.Controls.Add(this.aaaaaa);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource denekDataSetBindingSource;
        private DenekDataSet denekDataSet;
        private System.Windows.Forms.Label aaaaaa;
        private System.Windows.Forms.Label kırmızıadasdadasdsa;
        private DenekDataSetTableAdapters.oyuncubilTableAdapter oyuncubilTableAdapter1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label maviadsadsa;
        private System.Windows.Forms.Button dene;
        private System.Windows.Forms.Label yesil;
        private System.Windows.Forms.Label mavi;
        private System.Windows.Forms.Label kırmızı;
        private System.Windows.Forms.Label hak;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Sil;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}