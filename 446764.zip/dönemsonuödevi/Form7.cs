﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace dönemsonuödevi
{
    public partial class Form7 : Form
    {
        int hakv1 = 10;
        Random denek = new Random();
        int a = 0; 
        int b = 0; 
        int c = 0; 
        int d = 0; 
        int sayı = 0;
        int toplamHamle = 0;

        string connectionString = "Data Source=WILKINSON\\MSSQLSERVER01;Initial Catalog=Denek;Integrated Security=True";

        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs ea)
        {
            SkorTablosunuYukle();
        }

        
        private void SkorTablosunuYukle()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                   
                    string query = "SELECT TOP 5 ad, soyad, skor FROM oyuncubil WHERE LTRIM(RTRIM(zorluk)) = '4' AND skor IS NOT NULL ORDER BY skor ASC";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch { }
        }

        private void SkorKaydet(int hamleSayisi)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    
                    string checkSql = "SELECT COUNT(*) FROM oyuncubil WHERE ad = @ad AND soyad = @soyad AND zorluk = '4'";
                    SqlCommand checkCmd = new SqlCommand(checkSql, conn);
                    checkCmd.Parameters.AddWithValue("@ad", GlobalKullanici.Ad);
                    checkCmd.Parameters.AddWithValue("@soyad", GlobalKullanici.Soyad);
                    int varmi = (int)checkCmd.ExecuteScalar();

                    if (varmi > 0)
                    {
                       
                        string updateSql = "UPDATE oyuncubil SET skor = @skor WHERE ad = @ad AND soyad = @soyad AND zorluk = '4' AND (skor > @skor OR skor IS NULL)";
                        SqlCommand cmd = new SqlCommand(updateSql, conn);
                        cmd.Parameters.AddWithValue("@skor", hamleSayisi);
                        cmd.Parameters.AddWithValue("@ad", GlobalKullanici.Ad);
                        cmd.Parameters.AddWithValue("@soyad", GlobalKullanici.Soyad);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                       
                        string insertSql = "INSERT INTO oyuncubil (ad, soyad, skor, zorluk) VALUES (@ad, @soyad, @skor, '4')";
                        SqlCommand cmd = new SqlCommand(insertSql, conn);
                        cmd.Parameters.AddWithValue("@ad", GlobalKullanici.Ad);
                        cmd.Parameters.AddWithValue("@soyad", GlobalKullanici.Soyad);
                        cmd.Parameters.AddWithValue("@skor", hamleSayisi);
                        cmd.ExecuteNonQuery();
                    }
                }
                SkorTablosunuYukle();
            }
            catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
        }

        
        private void button12_Click(object sender, EventArgs ea) { richTextBox1.Text += "1"; BringToFront(); Focus(); }
        private void button11_Click(object sender, EventArgs ea) { richTextBox1.Text += "2"; BringToFront(); Focus(); }
        private void button3_Click(object sender, EventArgs ea) { richTextBox1.Text += "3"; BringToFront(); Focus(); }
        private void button4_Click(object sender, EventArgs ea) { richTextBox1.Text += "4"; BringToFront(); Focus(); }
        private void button5_Click(object sender, EventArgs ea) { richTextBox1.Text += "5"; BringToFront(); Focus(); }
        private void button6_Click(object sender, EventArgs ea) { richTextBox1.Text += "6"; BringToFront(); Focus(); }
        private void button7_Click(object sender, EventArgs ea) { richTextBox1.Text += "7"; BringToFront(); Focus(); }
        private void button8_Click(object sender, EventArgs ea) { richTextBox1.Text += "8"; BringToFront(); Focus(); }
        private void button9_Click(object sender, EventArgs ea) { richTextBox1.Text += "9"; BringToFront(); Focus(); }
        private void button10_Click(object sender, EventArgs ea) { richTextBox1.Text += "0"; BringToFront(); Focus(); }

        private void Sil_Click(object sender, EventArgs ea)
        {
            if (richTextBox1.Text.Length > 0)
                richTextBox1.Text = richTextBox1.Text.Substring(0, richTextBox1.Text.Length - 1);
            BringToFront(); Focus();
        }

       
        public void richTextBox1_TextChanged(object sender, EventArgs ea)
        {
            int cursorPos = richTextBox1.SelectionStart;
            string numbers = new string(richTextBox1.Text.Where(char.IsDigit).ToArray());
            if (numbers.Length > 4) numbers = numbers.Substring(0, 4);

            richTextBox1.TextChanged -= richTextBox1_TextChanged;
            richTextBox1.Clear();
            for (int i = 0; i < numbers.Length; i++)
            {
                int start = richTextBox1.TextLength;
                richTextBox1.AppendText(numbers[i].ToString());
                richTextBox1.Select(start, 1);
                if (numbers.Length == 4)
                {
                    if (i == 0) richTextBox1.SelectionColor = Color.Green;
                    else if (i == 1) richTextBox1.SelectionColor = Color.Yellow;
                    else if (i == 2) richTextBox1.SelectionColor = Color.Blue;
                    else if (i == 3) richTextBox1.SelectionColor = Color.Purple;
                }
            }
            richTextBox1.SelectionStart = Math.Min(cursorPos, richTextBox1.TextLength);
            richTextBox1.SelectionLength = 0;
            richTextBox1.TextChanged += richTextBox1_TextChanged;
        }

       
        private void button1_Click_1(object sender, EventArgs ea)
        {
            for (; ; )
            {
                a = denek.Next(1, 10); b = denek.Next(0, 10); c = denek.Next(0, 10); d = denek.Next(0, 10);
                if (a != b && a != c && a != d && b != c && b != d && c != d) break;
            }
            sayı = a * 1000 + b * 100 + c * 10 + d;
            hakv1 = 10; toplamHamle = 0;
            hak.Text = "10"; richTextBox1.Text = "";
            yesil.Text = "0"; mavi.Text = "0"; kırmızı.Text = "0";
        }

      
        private void dene_Click_1(object sender, EventArgs ea)
        {
            if (richTextBox1.Text.Length != 4) { MessageBox.Show("4 hane gir!"); return; }

            hakv1--; toplamHamle++;
            hak.Text = hakv1.ToString();
            int tahminv1 = Convert.ToInt32(richTextBox1.Text);

            int bin = tahminv1 / 1000;
            int yuz = (tahminv1 / 100) % 10;
            int onl = (tahminv1 / 10) % 10;
            int bir = tahminv1 % 10;

            int yes = 0; int mav = 0; int kir = 0;

            if (bin == a) yes++; else if (bin == b || bin == c || bin == d) mav++; else kir++;
            if (yuz == b) yes++; else if (yuz == a || yuz == c || yuz == d) mav++; else kir++;
            if (onl == c) yes++; else if (onl == a || onl == b || onl == d) mav++; else kir++;
            if (bir == d) yes++; else if (bir == a || bir == b || bir == c) mav++; else kir++;

            yesil.Text = yes.ToString(); mavi.Text = mav.ToString(); kırmızı.Text = kir.ToString();

            if (yes == 4)
            {
                MessageBox.Show("Tebrikler " + GlobalKullanici.Ad + "! Kazandın.");
                SkorKaydet(toplamHamle);
                button1_Click_1(sender, ea);
            }
            else if (hakv1 == 0)
            {
                MessageBox.Show("Bilemedin! Sayı: " + sayı);
                button1_Click_1(sender, ea);
            }
            richTextBox1.Text = "";
        }

      
        private void label4_Click(object sender, EventArgs ea) { MessageBox.Show(sayı.ToString()); }
        private void label4_DoubleClick(object sender, EventArgs ea) { MessageBox.Show(sayı.ToString()); }
        private void button2_Click_1(object sender, EventArgs ea) { Form6 frm6 = new Form6(); frm6.Show(); this.Hide(); }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs ea) { }
        private void label2_Click(object sender, EventArgs ea) { }
        private void label1_Click(object sender, EventArgs ea) { }
        private void button1_Click(object sender, EventArgs ea) { }
        private void textBox1_TextChanged(object sender, EventArgs ea) { }

        private void richTextBox1_TextChanged_1(object sender, EventArgs ea)
        {
        
            int cursorPos = richTextBox1.SelectionStart;

            
            string numbers = "";
            foreach (char c in richTextBox1.Text)
            {
                if (char.IsDigit(c)) numbers += c;
            }

           
            if (numbers.Length > 4) numbers = numbers.Substring(0, 4);

           
            richTextBox1.TextChanged -= richTextBox1_TextChanged_1;

          
            richTextBox1.Clear();
            Color[] renkler4Hane = { Color.Green, Color.Yellow, Color.Blue, Color.Purple };

            for (int i = 0; i < numbers.Length; i++)
            {
                int start = richTextBox1.TextLength;
                richTextBox1.AppendText(numbers[i].ToString());
                richTextBox1.Select(start, 1);

              
                if (numbers.Length == 4)
                {
                    richTextBox1.SelectionColor = renkler4Hane[i];
                }
                else
                {
                    richTextBox1.SelectionColor = Color.Black; 
                }
            }

            
            richTextBox1.SelectionStart = Math.Min(cursorPos, richTextBox1.TextLength);
            richTextBox1.SelectionLength = 0;
            richTextBox1.SelectionColor = Color.Black;
            richTextBox1.TextChanged += richTextBox1_TextChanged_1;
        }
        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void hak_Click(object sender, EventArgs e)
        {

        }
    }
}