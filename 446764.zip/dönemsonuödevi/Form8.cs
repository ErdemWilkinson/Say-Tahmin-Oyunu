﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace dönemsonuödevi
{
    public partial class Form8 : Form
    {
        int hakv1 = 10;
        Random denek = new Random();
        int a = 0; 
        int b = 0; 
        int c = 0;
        int d = 0; 
        int e = 0; 
        int sayı = 0;
        int toplamHamle = 0;

        string connectionString = "Data Source=WILKINSON\\MSSQLSERVER01;Initial Catalog=Denek;Integrated Security=True";

        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs ea)
        {
            SkorTablosunuYukle();
        }

        private void SkorTablosunuYukle()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    
                    string query = "SELECT TOP 5 ad, soyad, skor FROM oyuncubil WHERE zorluk = '5' AND skor IS NOT NULL ORDER BY skor ASC";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch { }
        }

        private void SkorKaydet(int hamleSayisi)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string sqlUpdate = "UPDATE oyuncubil SET skor = @skor, zorluk = '5' WHERE ad = @ad AND soyad = @soyad AND (skor > @skor OR skor IS NULL)";
                    using (SqlCommand cmd = new SqlCommand(sqlUpdate, conn))
                    {
                        cmd.Parameters.AddWithValue("@skor", hamleSayisi);
                        cmd.Parameters.AddWithValue("@ad", GlobalKullanici.Ad);
                        cmd.Parameters.AddWithValue("@soyad", GlobalKullanici.Soyad);
                        cmd.ExecuteNonQuery();
                    }
                }
                SkorTablosunuYukle();
            }
            catch { }
        }

        

        private void button12_Click(object sender, EventArgs ea) { richTextBox1.Text += "1"; }
        private void button11_Click(object sender, EventArgs ea) { richTextBox1.Text += "2"; }
        private void button3_Click(object sender, EventArgs ea) { richTextBox1.Text += "3"; }
        private void button4_Click(object sender, EventArgs ea) { richTextBox1.Text += "4"; }
        private void button5_Click(object sender, EventArgs ea) { richTextBox1.Text += "5"; }
        private void button6_Click(object sender, EventArgs ea) { richTextBox1.Text += "6"; }
        private void button7_Click(object sender, EventArgs ea) { richTextBox1.Text += "7"; }
        private void button8_Click(object sender, EventArgs ea) { richTextBox1.Text += "8"; }
        private void button9_Click(object sender, EventArgs ea) { richTextBox1.Text += "9"; }
        private void button10_Click(object sender, EventArgs ea) { richTextBox1.Text += "0"; }

        private void Sil_Click(object sender, EventArgs ea)
        {
            if (richTextBox1.Text.Length > 0)
                richTextBox1.Text = richTextBox1.Text.Substring(0, richTextBox1.Text.Length - 1);
        }

        
        public void richTextBox1_TextChanged_1(object sender, EventArgs ea)
        {
            
            int cursorPos = richTextBox1.SelectionStart;

            
            string numbers = new string(richTextBox1.Text.Where(char.IsDigit).ToArray());

            
            
            richTextBox1.TextChanged -= richTextBox1_TextChanged_1;
            richTextBox1.Clear();

            Color[] renkDizisi = { Color.Red, Color.Green, Color.Yellow, Color.Blue, Color.Purple };

            for (int i = 0; i < numbers.Length; i++)
            {
                int start = richTextBox1.TextLength;
                richTextBox1.AppendText(numbers[i].ToString());
                richTextBox1.Select(start, 1);

                
                if (numbers.Length == 5)
                {
                    richTextBox1.SelectionColor = renkDizisi[i];
                }
                else
                {
                    richTextBox1.SelectionColor = Color.Black; 
                }
            }

          
            richTextBox1.SelectionStart = Math.Min(cursorPos, richTextBox1.TextLength);
            richTextBox1.SelectionLength = 0;
            richTextBox1.SelectionColor = Color.Black;
            richTextBox1.TextChanged += richTextBox1_TextChanged_1;
        }

        
        private void button1_Click_1(object sender, EventArgs ea)
        {
            for (; ; )
            {
                a = denek.Next(1, 10); b = denek.Next(0, 10); c = denek.Next(0, 10); d = denek.Next(0, 10); e = denek.Next(0, 10);
                if (a != b && a != c && a != d && a != e && b != c && b != d && b != e && c != d && c != e && d != e) break;
            }
            sayı = a * 10000 + b * 1000 + c * 100 + d * 10 + e;
            hakv1 = 10; toplamHamle = 0;
            hak.Text = "10";
            richTextBox1.Text = "";
            yesil.Text = "0"; 
            mavi.Text = "0"; 
            kırmızı.Text = "0";
        }

      
        private void dene_Click_1(object sender, EventArgs ea)
        {
            if (richTextBox1.Text.Length != 5) { MessageBox.Show("5 hane gir!"); return; }

            hakv1--; 
            toplamHamle++;
            hak.Text = hakv1.ToString();
            int tahminv1 = Convert.ToInt32(richTextBox1.Text);

            int onb = tahminv1 / 10000;
            int bin = (tahminv1 / 1000) % 10;
            int yuz = (tahminv1 / 100) % 10;
            int onl = (tahminv1 / 10) % 10;
            int bir = tahminv1 % 10;

            int y = 0; int m = 0; int k = 0;

            if (onb == a) y++; else if (onb == b || onb == c || onb == d || onb == e) m++; else k++;
            if (bin == b) y++; else if (bin == a || bin == c || bin == d || bin == e) m++; else k++;
            if (yuz == c) y++; else if (yuz == a || yuz == b || yuz == d || yuz == e) m++; else k++;
            if (onl == d) y++; else if (onl == a || onl == b || onl == c || onl == e) m++; else k++;
            if (bir == e) y++; else if (bir == a || bir == b || bir == c || bir == d) m++; else k++;

            yesil.Text = y.ToString(); mavi.Text = m.ToString(); kırmızı.Text = k.ToString();

            if (y == 5)
            {
                MessageBox.Show("Tebrikler " + GlobalKullanici.Ad + "! Kazandın.");
                SkorKaydet(toplamHamle);
                button1_Click_1(sender, ea);
            }
            else if (hakv1 == 0)
            {
                MessageBox.Show("Bitti! Sayı: " + sayı);
                button1_Click_1(sender, ea);
            }
            richTextBox1.Text = "";
        }

        
        private void label4_Click(object sender, EventArgs ea) { MessageBox.Show(sayı.ToString()); }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs ea) { }
        private void label2_Click(object sender, EventArgs ea) { }
        private void label1_Click(object sender, EventArgs ea) { }
        private void button1_Click(object sender, EventArgs ea) { }
        private void textBox1_TextChanged(object sender, EventArgs ea) { }
        private void label4_DoubleClick(object sender, EventArgs ea) { MessageBox.Show(sayı.ToString()); }
    }
}