﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace dönemsonuödevi
{
    public partial class Form3: Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        
        private void giris_Click(object sender, EventArgs ea) 
        {
            string kullaniciAdi = textBox1.Text;
            string sifre = textBox2.Text;
            string connectionString = "Data Source=WILKINSON\\MSSQLSERVER01;Initial Catalog=Denek;Integrated Security=True";

            using (SqlConnection connect = new SqlConnection(connectionString))
            {
                connect.Open();
                
                string query = "SELECT ad, soyad FROM oyuncubil WHERE ad = @ad AND parola = @parola";
                using (SqlCommand command = new SqlCommand(query, connect))
                {
                    command.Parameters.AddWithValue("@ad", kullaniciAdi);
                    command.Parameters.AddWithValue("@parola", sifre);
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                      
                        GlobalKullanici.Ad = reader["ad"].ToString();
                        GlobalKullanici.Soyad = reader["soyad"].ToString();

                        Form4 frm4 = new Form4();
                        frm4.Show();
                        this.Hide();
                        MessageBox.Show($"Hoş geldin {GlobalKullanici.Ad}!");
                    }
                    else
                    {
                        MessageBox.Show("Hatalı ad veya şifre!");
                    }
                }
            }
        }
       

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }
    }
}
