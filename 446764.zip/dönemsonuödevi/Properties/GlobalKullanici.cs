﻿using System;

namespace dönemsonuödevi
{
    // Tüm formlardan erişilebilir global kullanıcı bilgisi
    public static class GlobalKullanici
    {
        public static string Ad { get; set; }
        public static string Soyad { get; set; }
        public static int KullaniciID { get; set; }

        // Kullanıcı bilgilerini temizle (çıkış yaparken)
        public static void Temizle()
        {
            Ad = null;
            Soyad = null;
            KullaniciID = 0;
        }
    }
}