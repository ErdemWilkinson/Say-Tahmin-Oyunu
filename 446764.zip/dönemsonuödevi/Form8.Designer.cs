﻿using System;
using System.Windows.Forms;

namespace dönemsonuödevi
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sil = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.hak = new System.Windows.Forms.Label();
            this.kırmızı = new System.Windows.Forms.Label();
            this.mavi = new System.Windows.Forms.Label();
            this.yesil = new System.Windows.Forms.Label();
            this.dene = new System.Windows.Forms.Button();
            this.maviadsadsa = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.kırmızıadasdadasdsa = new System.Windows.Forms.Label();
            this.aaaaaa = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Sil
            // 
            this.Sil.Location = new System.Drawing.Point(166, 348);
            this.Sil.Name = "Sil";
            this.Sil.Size = new System.Drawing.Size(35, 36);
            this.Sil.TabIndex = 61;
            this.Sil.Text = "Sil";
            this.Sil.UseVisualStyleBackColor = true;
            this.Sil.Click += new System.EventHandler(this.Sil_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(125, 348);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(35, 36);
            this.button10.TabIndex = 60;
            this.button10.Text = "0";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(166, 306);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 36);
            this.button9.TabIndex = 59;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(125, 306);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(35, 36);
            this.button8.TabIndex = 58;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(84, 306);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 36);
            this.button7.TabIndex = 57;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(166, 264);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 36);
            this.button6.TabIndex = 56;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(125, 264);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 36);
            this.button5.TabIndex = 55;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(84, 264);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 36);
            this.button4.TabIndex = 54;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(166, 222);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 36);
            this.button3.TabIndex = 53;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(125, 222);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(35, 36);
            this.button11.TabIndex = 52;
            this.button11.Text = "2";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(84, 222);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(35, 36);
            this.button12.TabIndex = 51;
            this.button12.Text = "1";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Impact", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.richTextBox1.Location = new System.Drawing.Point(295, 151);
            this.richTextBox1.MaxLength = 5;
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(311, 29);
            this.richTextBox1.TabIndex = 50;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(37, 151);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 25);
            this.label1.TabIndex = 49;
            this.label1.Text = "Kalan hak sayınız:";
            // 
            // hak
            // 
            this.hak.AutoSize = true;
            this.hak.Font = new System.Drawing.Font("Palatino Linotype", 16.30189F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.hak.ForeColor = System.Drawing.Color.Navy;
            this.hak.Location = new System.Drawing.Point(235, 146);
            this.hak.Name = "hak";
            this.hak.Size = new System.Drawing.Size(41, 34);
            this.hak.TabIndex = 48;
            this.hak.Text = "10";
            // 
            // kırmızı
            // 
            this.kırmızı.AutoSize = true;
            this.kırmızı.ForeColor = System.Drawing.Color.Crimson;
            this.kırmızı.Location = new System.Drawing.Point(541, 206);
            this.kırmızı.Name = "kırmızı";
            this.kırmızı.Size = new System.Drawing.Size(13, 13);
            this.kırmızı.TabIndex = 47;
            this.kırmızı.Text = "0";
            // 
            // mavi
            // 
            this.mavi.AutoSize = true;
            this.mavi.ForeColor = System.Drawing.Color.Navy;
            this.mavi.Location = new System.Drawing.Point(410, 206);
            this.mavi.Name = "mavi";
            this.mavi.Size = new System.Drawing.Size(13, 13);
            this.mavi.TabIndex = 46;
            this.mavi.Text = "0";
            // 
            // yesil
            // 
            this.yesil.AutoSize = true;
            this.yesil.ForeColor = System.Drawing.Color.Lime;
            this.yesil.Location = new System.Drawing.Point(296, 206);
            this.yesil.Name = "yesil";
            this.yesil.Size = new System.Drawing.Size(13, 13);
            this.yesil.TabIndex = 45;
            this.yesil.Text = "0";
            // 
            // dene
            // 
            this.dene.Location = new System.Drawing.Point(680, 163);
            this.dene.Name = "dene";
            this.dene.Size = new System.Drawing.Size(84, 38);
            this.dene.TabIndex = 44;
            this.dene.Text = "Dene!";
            this.dene.UseVisualStyleBackColor = true;
            this.dene.Click += new System.EventHandler(this.dene_Click_1);
            // 
            // maviadsadsa
            // 
            this.maviadsadsa.AutoSize = true;
            this.maviadsadsa.ForeColor = System.Drawing.Color.MidnightBlue;
            this.maviadsadsa.Location = new System.Drawing.Point(429, 206);
            this.maviadsadsa.Name = "maviadsadsa";
            this.maviadsadsa.Size = new System.Drawing.Size(29, 13);
            this.maviadsadsa.TabIndex = 43;
            this.maviadsadsa.Text = "mavi";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(680, 98);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 38);
            this.button1.TabIndex = 42;
            this.button1.Text = "Yeni oyun / yeniden başla";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Symbol", 14.26415F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label4.Location = new System.Drawing.Point(251, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(361, 30);
            this.label4.TabIndex = 41;
            this.label4.Text = "5 BASAMAKLI SAYI BILME OYUNU";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            this.label4.DoubleClick += new System.EventHandler(this.label4_DoubleClick);
            // 
            // kırmızıadasdadasdsa
            // 
            this.kırmızıadasdadasdsa.AutoSize = true;
            this.kırmızıadasdadasdsa.ForeColor = System.Drawing.Color.Crimson;
            this.kırmızıadasdadasdsa.Location = new System.Drawing.Point(560, 206);
            this.kırmızıadasdadasdsa.Name = "kırmızıadasdadasdsa";
            this.kırmızıadasdadasdsa.Size = new System.Drawing.Size(35, 13);
            this.kırmızıadasdadasdsa.TabIndex = 40;
            this.kırmızıadasdadasdsa.Text = "kırmızı";
            // 
            // aaaaaa
            // 
            this.aaaaaa.AutoSize = true;
            this.aaaaaa.ForeColor = System.Drawing.Color.LawnGreen;
            this.aaaaaa.Location = new System.Drawing.Point(315, 206);
            this.aaaaaa.Name = "aaaaaa";
            this.aaaaaa.Size = new System.Drawing.Size(27, 13);
            this.aaaaaa.TabIndex = 39;
            this.aaaaaa.Text = "yeşil";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(299, 282);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 45;
            this.dataGridView1.Size = new System.Drawing.Size(464, 115);
            this.dataGridView1.TabIndex = 62;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 16.30189F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(470, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 33);
            this.label2.TabIndex = 63;
            this.label2.Text = "Skor Tablosu";
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Sil);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hak);
            this.Controls.Add(this.kırmızı);
            this.Controls.Add(this.mavi);
            this.Controls.Add(this.yesil);
            this.Controls.Add(this.dene);
            this.Controls.Add(this.maviadsadsa);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.kırmızıadasdadasdsa);
            this.Controls.Add(this.aaaaaa);
            this.Name = "Form8";
            this.Text = "Form8";
            this.Load += new System.EventHandler(this.Form8_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.Button Sil;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        public System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label hak;
        private System.Windows.Forms.Label kırmızı;
        private System.Windows.Forms.Label mavi;
        private System.Windows.Forms.Label yesil;
        private System.Windows.Forms.Button dene;
        private System.Windows.Forms.Label maviadsadsa;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label kırmızıadasdadasdsa;
        private System.Windows.Forms.Label aaaaaa;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Label label2;
    }
}