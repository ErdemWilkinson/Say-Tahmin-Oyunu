﻿namespace dönemsonuödevi
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.denekDataSet = new dönemsonuödevi.DenekDataSet();
            this.denekDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kayıt = new System.Windows.Forms.Button();
            this.giris = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // denekDataSet
            // 
            this.denekDataSet.DataSetName = "DenekDataSet";
            this.denekDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // denekDataSetBindingSource
            // 
            this.denekDataSetBindingSource.DataSource = this.denekDataSet;
            this.denekDataSetBindingSource.Position = 0;
            // 
            // kayıt
            // 
            this.kayıt.BackColor = System.Drawing.Color.Coral;
            this.kayıt.ForeColor = System.Drawing.Color.DarkBlue;
            this.kayıt.Location = new System.Drawing.Point(189, 121);
            this.kayıt.Name = "kayıt";
            this.kayıt.Size = new System.Drawing.Size(176, 167);
            this.kayıt.TabIndex = 0;
            this.kayıt.Text = "Kayıt ol";
            this.kayıt.UseVisualStyleBackColor = false;
            this.kayıt.Click += new System.EventHandler(this.button1_Click);
            // 
            // giris
            // 
            this.giris.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.giris.ForeColor = System.Drawing.Color.Indigo;
            this.giris.Location = new System.Drawing.Point(442, 121);
            this.giris.Name = "giris";
            this.giris.Size = new System.Drawing.Size(184, 167);
            this.giris.TabIndex = 1;
            this.giris.Text = "Giriş yap!";
            this.giris.UseVisualStyleBackColor = false;
            this.giris.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Olive;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.giris);
            this.Controls.Add(this.kayıt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.denekDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource denekDataSetBindingSource;
        private DenekDataSet denekDataSet;
        private System.Windows.Forms.Button kayıt;
        private System.Windows.Forms.Button giris;
    }
}

