﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dönemsonuödevi
{

    public partial class Form6 : Form
    {
        Form5 form5;

        public Form6()
        {
            InitializeComponent();
            form5 = new Form5();
            form5.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "4";
            form5.BringToFront();
            form5.Focus();
        }

        private void Sil_Click(object sender, EventArgs e)
        {
            if (form5.richTextBox1.Text.Length > 0)
            {
                form5.richTextBox1.Text = form5.richTextBox1.Text.Substring(0, form5.richTextBox1.Text.Length - 1);
            }
            form5.BringToFront();
            form5.Focus();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "6";
            form5.BringToFront();
            form5.Focus();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "2";
            form5.BringToFront();
            form5.Focus();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "3";
            form5.BringToFront();
            form5.Focus();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "5";
            form5.BringToFront();
            form5.Focus();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "7";
            form5.BringToFront();
            form5.Focus();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "8";
            form5.BringToFront();
            form5.Focus();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "9";
            form5.BringToFront();
            form5.Focus();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            form5.richTextBox1.Text += "0";
            form5.BringToFront();
            form5.Focus();
        }
    }
}
