﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace dönemsonuödevi
{
    public partial class Form2: Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        string connectionString = "Data Source=WILKINSON\\MSSQLSERVER01;Initial Catalog=Denek;Integrated Security=True";
        SqlConnection connect = new SqlConnection();

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void kayıt_Click(object sender, EventArgs e)
        {
            string oyuncuad = textBox1.Text;
            string oyuncusoyad = textBox2.Text;
            string email = textBox3.Text;
            string telefon = textBox4.Text;
            string sifre = textBox5.Text;

            if (string.IsNullOrWhiteSpace(oyuncuad) || string.IsNullOrWhiteSpace(oyuncusoyad) || 
               
                string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(telefon) ||

                string.IsNullOrWhiteSpace(sifre))
            {
                MessageBox.Show("Lütfen tüm alanları doldurun!");
                return;
            }

            try
            {
                using (SqlConnection connect = new SqlConnection(connectionString))
                {
                    connect.Open();
                    string query = "INSERT INTO oyuncubil (ad, soyad, eposta, telefon, parola) " +
                                   "VALUES (@oyuncuad, @oyuncusoyad, @email, @telefon, @sifre)";
                    using (SqlCommand command = new SqlCommand(query, connect))
                    {
                        command.Parameters.AddWithValue("@oyuncuad", oyuncuad);
                        command.Parameters.AddWithValue("@oyuncusoyad", oyuncusoyad);
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@telefon", telefon);
                        command.Parameters.AddWithValue("@sifre", sifre);
                        int result = command.ExecuteNonQuery();
                        if (result > 0)
                        {
                            MessageBox.Show("Kayıt başarılı!");
                        }
                        else
                        {
                            MessageBox.Show("Kayıt başarısız. Lütfen tekrar deneyin.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }



        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.PasswordChar = '*';
        }

        private void geri_Click(object sender, EventArgs e)
        {
          
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
        }
    }
}
